package br.com.nava.Entities;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.modelmapper.ModelMapper;

import br.com.nava.dtos.SerieDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table( name = "SERIES")
public class SerieEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id; 
	
	private String titulo;
	private String autor;
	private String genero;
	private String  duracao;
	private Integer temporadas;
	private Integer episodios;
	private String idioma;
	private Integer anoDeLancamento;
	private Integer anoDeEncerramento;

	
	
	//conversão de entity para dto
	
	public SerieDTO toDTO() {
		
		ModelMapper mapper = new ModelMapper();
		
		SerieDTO dto = mapper.map(this, SerieDTO.class);
		
		return dto;
	

}
	
}
