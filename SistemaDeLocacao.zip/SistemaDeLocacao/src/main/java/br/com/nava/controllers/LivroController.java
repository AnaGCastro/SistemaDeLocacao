package br.com.nava.controllers;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.nava.dtos.LivroDTO;
import br.com.nava.services.LivroService;

@RestController
@RequestMapping("/livros")
public class LivroController {
	
	@Autowired
	
	LivroService livroService;
	
	@GetMapping()
	public ResponseEntity<List<LivroDTO>> getAll(){
		
		return ResponseEntity.status(HttpStatus.OK).body(livroService.getAll());
		
	}
	
	@GetMapping("{id}")
	
	public ResponseEntity<LivroDTO> getOne(@PathVariable int id){
		
		return ResponseEntity.status(HttpStatus.OK).body(livroService.getOne(id));
	}
	
	@PostMapping()
	public ResponseEntity<LivroDTO> save(@Validated  @RequestBody LivroDTO livro){
		
		return ResponseEntity.status(HttpStatus.OK).body(livroService.save(livro.toEntity()));
	
	}
	
	
	@PatchMapping("{id}")
	
	public ResponseEntity<LivroDTO> update(@PathVariable int id, @RequestBody LivroDTO livro ){
		
		
		return ResponseEntity.status(HttpStatus.OK).body(livroService.update(id, livro.toEntity()));
	}
		

	@DeleteMapping(value = "{id}")
	
	public void delete(@PathVariable int id) {
		
		livroService.delete(id);
	}
		
	
	
	
	

}
