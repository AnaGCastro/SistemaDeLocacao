package br.com.nava.Entities;



import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.modelmapper.ModelMapper;


import br.com.nava.dtos.LivroDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "LIVROS")
public class LivroEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private int id; 
	
	private String titulo;
	private String autor;
	private String editora;
	private String genero;
	private Integer qtdePaginas;
	private Integer qtdeLivros;
	private String idioma;
	private Integer anoPublicacao;
	private float preco;
	

	
	//conversão de entity para dto
	
	public LivroDTO toDTO() {
		
		ModelMapper mapper = new ModelMapper();
		
		LivroDTO dto = mapper.map(this, LivroDTO.class);
		
		return dto;
	}
	
	

}
