package br.com.nava.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.nava.dtos.SerieDTO;
import br.com.nava.services.SerieService;

@RestController
@RequestMapping("/series")
public class SerieController {
	
	@Autowired
	
	SerieService serieService;
	
	@GetMapping()
	
	public ResponseEntity<List<SerieDTO>> getAll(){
		
		return ResponseEntity.status(HttpStatus.OK).body(serieService.getAll());
		
		
	}
	
	@GetMapping("{id}")
	
	public ResponseEntity<SerieDTO> getOne(@PathVariable int id) {
		
		return ResponseEntity.status(HttpStatus.OK).body(serieService.getOne(id));
	}
	
	
	@PostMapping()
	
	public ResponseEntity<SerieDTO> save(@Validated @RequestBody SerieDTO serie) {
		
		return ResponseEntity.status(HttpStatus.OK).body(serieService.save(serie.toEntity()));
	}
	
	@PatchMapping("{id}")
	
	public ResponseEntity<SerieDTO> update(@PathVariable int id, @RequestBody SerieDTO serie) {
		
		return ResponseEntity.status(HttpStatus.OK).body(serieService.update(id, serie.toEntity()));
	}
	
	@DeleteMapping(value = "{id}")
	
	public void delete(@PathVariable int id) {
		
		serieService.delete(id);
	}
	
	
	
	

}
