package br.com.nava.Entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.modelmapper.ModelMapper;

import br.com.nava.dtos.FilmeDTO;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name = "FILMES")
public class FilmeEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	private int id;
	private String titulo;
	private String diretor;
	private String genero;
	private String idioma;
	private Integer qtdeFilmes;
	private String paisOrigem;
	private Integer anoDeLancamento;

	// conversão de entity para dto

	public FilmeDTO toDTO() {

		ModelMapper mapper = new ModelMapper();

		FilmeDTO dto = mapper.map(this, FilmeDTO.class);

		return dto;

	}

}
