package br.com.nava.services;


import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.nava.Entities.LivroEntity;
import br.com.nava.Repositories.LivroRepository;
import br.com.nava.dtos.LivroDTO;

@Service
public class LivroService {

	@Autowired
	private LivroRepository livroRepository;
	
	public List<LivroDTO> getAll(){
		
		List<LivroEntity> listaEntity = livroRepository.findAll();
		
		List<LivroDTO> listaDTO = new ArrayList<>();
		
		for (LivroEntity entity: listaEntity) {
			
			listaDTO.add(entity.toDTO());
		}
		
		return listaDTO;
		
	}
	
	public LivroDTO getOne (Integer id) {
		
		Optional<LivroEntity> optional = livroRepository.findById(id);
		LivroEntity livro = optional.orElse(new LivroEntity());
		return livro.toDTO();
		
	}
	
	public LivroDTO save ( LivroEntity livro) {
		
		return this.livroRepository.save(livro).toDTO();
		
		
	}
	
	public LivroDTO update(int id, LivroEntity novoLivro) {
		
		Optional<LivroEntity> optional = livroRepository.findById(id);
		
		if (optional.isPresent()) {
			
			LivroEntity livro = optional.get();
			
			livro.setTitulo(novoLivro.getTitulo());
			livro.setAutor(novoLivro.getAutor());
			livro.setEditora(novoLivro.getEditora());
			livro.setGenero(novoLivro.getGenero());
			livro.setQtdePaginas(novoLivro.getQtdePaginas());
			livro.setQtdeLivros(novoLivro.getQtdeLivros());
			livro.setIdioma(novoLivro.getIdioma());
			livro.setAnoPublicacao(novoLivro.getAnoPublicacao());
			livro.setPreco(novoLivro.getPreco());
			
	
			
			return livroRepository.save(livro).toDTO();
			
		} else {
			
			return new LivroEntity().toDTO();
			
		}
		
		
	}
	
	public  void delete(int id) {
		
		livroRepository.deleteById(id);
	}
	
}
