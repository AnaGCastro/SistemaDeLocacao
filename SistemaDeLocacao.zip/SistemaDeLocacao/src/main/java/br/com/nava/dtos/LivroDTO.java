package br.com.nava.dtos;



import org.modelmapper.ModelMapper;
import br.com.nava.Entities.LivroEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LivroDTO {
	
	private int id;

	private String titulo;
	private String autor;
	private String editora;
	private String genero;
	private Integer qtdePaginas;
	private Integer qtdeLivros;
	private String idioma;
	private Integer anoPublicacao;
	private float preco;
	
	
	//conversão de dto para entity
	public LivroEntity toEntity() {
		
		ModelMapper mapper = new ModelMapper();
		
		return mapper.map(this, LivroEntity.class);
	}
	

}
