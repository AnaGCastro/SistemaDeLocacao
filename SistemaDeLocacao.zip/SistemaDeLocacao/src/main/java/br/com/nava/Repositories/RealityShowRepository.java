package br.com.nava.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.nava.Entities.RealityShowEntity;

public interface RealityShowRepository  extends JpaRepository<RealityShowEntity, Integer>{

}
