package br.com.nava.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.nava.Entities.FilmeEntity;

public interface FilmeRepository extends JpaRepository<FilmeEntity, Integer> {

}
