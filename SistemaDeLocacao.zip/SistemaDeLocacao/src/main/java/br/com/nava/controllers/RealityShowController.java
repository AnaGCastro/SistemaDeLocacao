package br.com.nava.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.nava.dtos.RealityShowDTO;
import br.com.nava.services.RealityShowService;

@RestController
@RequestMapping("/realities")
public class RealityShowController {
	
	
	@Autowired
	
	RealityShowService realityShowService;
	
	
	@GetMapping()
	
	public ResponseEntity<List<RealityShowDTO>> getAll(){
		
		return ResponseEntity.status(HttpStatus.OK).body(realityShowService.getAll());
		
		
	}
	
	
	@GetMapping("{id}")
	
	public ResponseEntity<RealityShowDTO> getOne(@PathVariable int id) {
		
		return ResponseEntity.status(HttpStatus.OK).body(realityShowService.getOne(id));
	}
	
	@PostMapping()
	
	public ResponseEntity<RealityShowDTO> save(@Validated @RequestBody RealityShowDTO reality) {
		
		return ResponseEntity.status(HttpStatus.OK).body(realityShowService.save(reality.toEntity()));
	}
	
	@PatchMapping("{id}")
	
	public ResponseEntity<RealityShowDTO> update(@PathVariable int id, @RequestBody RealityShowDTO reality) {
		
		return ResponseEntity.status(HttpStatus.OK).body(realityShowService.update(id, reality.toEntity()));
	}
	
	@DeleteMapping( value = "{id}")
	
	public void delete(@PathVariable int id) {
		
		realityShowService.delete(id);
		
	}
	
	

}
