package br.com.nava.dtos;

import org.modelmapper.ModelMapper;

import br.com.nava.Entities.FilmeEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FilmeDTO {
	
	
	private int id;
	private String titulo;
	private String diretor;
	private String genero;
	private String idioma;
	private Integer quantidadeFilmes; 
	private String paisOrigem;
	private Integer anoDeLancamento;
	
	
	//conversão de dto para entity
	public FilmeEntity toEntity() {
		
		ModelMapper mapper = new ModelMapper();
		
		return mapper.map(this, FilmeEntity.class);
	}

}
