package br.com.nava.dtos;

import org.modelmapper.ModelMapper;


import br.com.nava.Entities.RealityShowEntity;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class RealityShowDTO {

	private int id;

	private String titulo;
	private String emissoura;
	private Integer temporadas;
	private Integer episodios;
	private String idioma;
	private Integer anoDeEstreia;

	// conversão de dto para entity
	public RealityShowEntity toEntity() {

		ModelMapper mapper = new ModelMapper();

		return mapper.map(this, RealityShowEntity.class);
	}

}
