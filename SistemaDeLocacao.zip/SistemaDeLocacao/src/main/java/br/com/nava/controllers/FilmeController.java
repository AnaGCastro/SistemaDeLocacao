package br.com.nava.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import br.com.nava.dtos.FilmeDTO;
import br.com.nava.services.FilmeService;

@RestController
@RequestMapping("/filmes")
public class FilmeController {
	
	@Autowired
	
	FilmeService filmeService;
	
	@GetMapping()
	public ResponseEntity<List<FilmeDTO>> getAll(){
		
		return ResponseEntity.status(HttpStatus.OK).body(filmeService.getAll());
		
		
	}
	
	@GetMapping("{id}")
	
	public ResponseEntity<FilmeDTO> getOne (@PathVariable int id) {
		
		return ResponseEntity.status(HttpStatus.OK).body(filmeService.getOne(id));
				
	}
	
	@PostMapping()
	
	public ResponseEntity<FilmeDTO> save(@Validated @RequestBody FilmeDTO filme) {
		
		return ResponseEntity.status(HttpStatus.OK).body(filmeService.save(filme.toEntity()));
	}
	
	@PatchMapping("{id}")
	
	public ResponseEntity<FilmeDTO> update(@PathVariable int id, @RequestBody FilmeDTO filme) {
		
		return ResponseEntity.status(HttpStatus.OK).body(filmeService.update(id, filme.toEntity()));
	}
	
	
	@DeleteMapping(value = "{id}")
	
	public void delete(@PathVariable int id) {
		
		filmeService.delete(id);
	}

		

		
		
	}

	
	


