package br.com.nava.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import br.com.nava.Entities.SerieEntity;

public interface SerieRepository extends JpaRepository<SerieEntity, Integer> {

}
