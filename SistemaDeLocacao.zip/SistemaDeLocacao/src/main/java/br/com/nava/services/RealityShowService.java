package br.com.nava.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.nava.Entities.RealityShowEntity;
import br.com.nava.Repositories.RealityShowRepository;
import br.com.nava.dtos.RealityShowDTO;

@Service
public class RealityShowService {

	@Autowired

	RealityShowRepository realityShowRepository;

	public List<RealityShowDTO> getAll() {

		List<RealityShowEntity> listaEntity = realityShowRepository.findAll();

		List<RealityShowDTO> listaDTO = new ArrayList<>();

		for (RealityShowEntity entity : listaEntity) {

			listaDTO.add(entity.toDTO());
		}

		return listaDTO;

	}

	public RealityShowDTO getOne(Integer id) {

		Optional<RealityShowEntity> optional = realityShowRepository.findById(id);

		RealityShowEntity reality = optional.orElse(new RealityShowEntity());

		return reality.toDTO();
	}

	public RealityShowDTO save(RealityShowEntity reality) {

		return this.realityShowRepository.save(reality).toDTO();

	}

	public RealityShowDTO update(int id, RealityShowEntity novoReality) {

		Optional<RealityShowEntity> optional = realityShowRepository.findById(id);

		if (optional.isPresent()) {

			RealityShowEntity reality = optional.get();

			reality.setTitulo(novoReality.getTitulo());
			reality.setEmissoura(novoReality.getEmissoura());
			reality.setTemporadas(novoReality.getTemporadas());
			reality.setEpisodios(novoReality.getEpisodios());
			reality.setIdioma(novoReality.getIdioma());
			reality.setAnoDeEstreia(novoReality.getAnoDeEstreia());

			return realityShowRepository.save(reality).toDTO();

		} else {

			return new RealityShowEntity().toDTO();

		}

	}

	public void delete(int id) {

		realityShowRepository.deleteById(id);
	}

}
