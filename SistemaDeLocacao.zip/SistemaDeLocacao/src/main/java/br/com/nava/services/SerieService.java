package br.com.nava.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.nava.Entities.SerieEntity;
import br.com.nava.Repositories.SerieRepository;
import br.com.nava.dtos.SerieDTO;

@Service
public class SerieService {

	@Autowired

	SerieRepository serieRepository;

	public List<SerieDTO> getAll() {

		List<SerieEntity> listaEntity = serieRepository.findAll();

		List<SerieDTO> listaDTO = new ArrayList<>();

		for (SerieEntity entity : listaEntity) {

			listaDTO.add(entity.toDTO());

		}

		return listaDTO;

	}

	public SerieDTO getOne(Integer id) {

		Optional<SerieEntity> optional = serieRepository.findById(id);

		SerieEntity serie = optional.orElse(new SerieEntity());

		return serie.toDTO();
	}

	public SerieDTO save(SerieEntity serie) {

		return this.serieRepository.save(serie).toDTO();

	}

	public SerieDTO update(int id, SerieEntity novaSerie) {

		Optional<SerieEntity> optional = serieRepository.findById(id);
		
		if (optional.isPresent()) {
			
			SerieEntity serie = optional.get();
			
			
			serie.setTitulo(novaSerie.getTitulo());
			serie.setAutor(novaSerie.getAutor());
			serie.setGenero(novaSerie.getGenero());
			serie.setDuracao(novaSerie.getDuracao());
			serie.setTemporadas(novaSerie.getTemporadas());
			serie.setEpisodios(novaSerie.getEpisodios());
			serie.setIdioma(novaSerie.getIdioma());
			serie.setAnoDeLancamento(novaSerie.getAnoDeLancamento());
			serie.setAnoDeEncerramento(novaSerie.getAnoDeEncerramento());
			
			return serieRepository.save(serie).toDTO();			

		} else {
			
			return new SerieEntity().toDTO();
		}

	}
	
	public void delete(int id) {
		
		serieRepository.deleteById(id);
	}

}
