package br.com.nava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaDeLocacaoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaDeLocacaoApplication.class, args);
	}

}
