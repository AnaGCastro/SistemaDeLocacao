package br.com.nava.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.nava.Entities.FilmeEntity;
import br.com.nava.Repositories.FilmeRepository;
import br.com.nava.dtos.FilmeDTO;

@Service
public class FilmeService {

	@Autowired

	FilmeRepository filmeRepository;

	public List<FilmeDTO> getAll() {

		List<FilmeEntity> listaEntity = filmeRepository.findAll();

		List<FilmeDTO> listaDTO = new ArrayList<>();

		for (FilmeEntity entity : listaEntity) {

			listaDTO.add(entity.toDTO());
		}

		return listaDTO;
	}

	public FilmeDTO getOne(Integer id) {

		Optional<FilmeEntity> optional = filmeRepository.findById(id);

		FilmeEntity filme = optional.orElse(new FilmeEntity());

		return filme.toDTO();

	}

	public FilmeDTO save(FilmeEntity filme) {

		return this.filmeRepository.save(filme).toDTO();
	}

	public FilmeDTO update(int id, FilmeEntity novoFilme) {

		Optional<FilmeEntity> optional = filmeRepository.findById(id);

		if (optional.isPresent()) {

			FilmeEntity filme = optional.get();

			filme.setTitulo(novoFilme.getTitulo());
			filme.setDiretor(novoFilme.getDiretor());
			filme.setGenero(novoFilme.getGenero());
			filme.setIdioma(novoFilme.getIdioma());
			filme.setQtdeFilmes(novoFilme.getQtdeFilmes());
			filme.setPaisOrigem(novoFilme.getPaisOrigem());
			filme.setAnoDeLancamento(novoFilme.getAnoDeLancamento());

			return filmeRepository.save(filme).toDTO();

		} else {

			return new FilmeEntity().toDTO();
		}

	}

	public void delete(int id) {

		filmeRepository.deleteById(id);
	}

}
